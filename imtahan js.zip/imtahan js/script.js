

//1.tapshiriq yash 

//function Check() {

//    alert('yasinizi daxil edin')

//   let inp = 20;
//  let userinp = document.getElementById('inp');

//  if (userinp.value == inp) {

//   Swal.fire({
//        icon: 'success',
//      title: 'Oops...',
//      text: 'duzdur',

//  })

//} else {

//  Swal.fire({
//  icon: 'error',
//   title: 'Oops...',
//    text: 'Something went wrong!',

// })
// }
//}//





//2.sifrenin uzunlugu
//function Check() {
// let alfa = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
//     'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

// let inp = document.getElementById('inp');
// let show = document.getElementById('show');
// let count = 1;
// for (let i = 0; i < inp.value.length; i++) {

//    if (inp.value[i] == " " && inp.value[i+1] !==" " ) {

//      count++
//  }

// }
//  show.innerHTML = count;
//}




//3. Random shifre

//function Check() {


 //   let show = document.getElementById('show');
  //  let inp = document.getElementById('inp');

 //   let alfa = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
 //       'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'];
 //   let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 22, 33, 55, 44, 55, 66, 88, 77, 99];
 //   let simvol = ['@', '#', '$', '%', '^', '&', '&', '*'];
  //  let newArray = alfa.concat(numbers, simvol)
 //   let rnd;
  //  let data = "";
  //  for (let i = 0; i < inp.value; i++) {

 //       rnd = Math.floor(Math.random() * newArray.length);
   //     data += newArray[rnd]

  
  //  }
  //  show.innerHTML = data;

//}


